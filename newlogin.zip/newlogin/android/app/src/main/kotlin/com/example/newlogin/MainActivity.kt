package com.example.newlogin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
