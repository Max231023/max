import 'dart:async';
import 'package:flutter/material.dart';
import 'package:newlogin/homepage.dart';
import 'package:newlogin/model/LoginApi/LoginApi.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';


class splash extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}
class _MyHomePageState extends State<splash> {
  var isLoggedin;

  @override
  void initState() {
    navigate();
    super.initState();

    Timer(Duration(seconds: 3),
            ()=>Navigator.pushReplacement(context,
            MaterialPageRoute(builder:
                (context) => isLoggedin ? HomePage() : login()
            )
        )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child:Image.asset(
          'assets/abc.png',
          fit:BoxFit.fill
      ),
    );
  }
  void navigate() async{
    SharedPreferences prefs = await SharedPreferences.getInstance();
    isLoggedin = prefs.getBool('isLoggedin') ?? false;;
  }

}