
class LoginApi {

  bool status;
  String data;

	LoginApi.fromJsonMap(Map<String, dynamic> map): 
		status = map["status"],
		data = map["data"];

	Map<String, dynamic> toJson() {
		final Map<String, dynamic> data = new Map<String, dynamic>();
		data['status'] = status;
		data['data'] = data;
		return data;
	}
}
