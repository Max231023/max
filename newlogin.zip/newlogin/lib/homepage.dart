import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor:Color(0xFFF93822),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(
            bottom: Radius.circular(30),
          ),
        ),
        title:Text('Dashboard',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 18)),
        actions: <Widget>[
          SizedBox(width: 10,),
        ],
      ),

      drawer: Drawer(
        backgroundColor: Colors.white,
        elevation: 25,
        child: Column(
          children: [
            UserAccountsDrawerHeader(accountName: Text("xyz"),
                accountEmail: Text("xyz@gmail.com")
            ),
            ListTile(
              title: Text("home"),
              leading: Icon(Icons.home),

            ),
            ListTile(
              title: Text("settings"),
              leading: Icon(Icons.settings),
            ),
            Divider(
              height: 10,
              thickness: 2,
            ),
          ],
        ),
      ),
    );
  }
}
