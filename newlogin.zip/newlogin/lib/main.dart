import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:http/http.dart' as http;
import 'package:newlogin/homepage.dart';
import 'package:newlogin/splash.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'model/LoginApi/LoginApi.dart';
import 'package:newlogin/color.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final SharedPreferences prefs = await SharedPreferences.getInstance();
  var isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: isLoggedIn? splash() : login(),
  ));
}

class myapp extends StatelessWidget {
  const myapp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme:
      ThemeData(
          primaryColor: Color(0xFFF93822),accentColor: Color(0xFFF93822)),
      debugShowCheckedModeBanner: false,
      home: splash(),
    );
  }
}
 class login extends StatefulWidget {
   const login({Key? key}) : super(key: key);

   @override
   _loginState createState() => _loginState();
 }

 class _loginState extends State<login> {

   TextEditingController emailController = new TextEditingController();
   TextEditingController passwordController = new TextEditingController();
   bool _obscureTextNewPassword = true;
   final formKey = new GlobalKey<FormState>();
   bool _isLoading = false;
   late final AutovalidateMode autovalidateMode;


   String? validatePassword(String value) {
     if (value.isEmpty) {
       return "* Required";
     } else if (value.length < 6) {
       return "Password should be atleast 6 characters";
     } else if (value.length > 15) {
       return "Password should not be greater than 15 characters";
     } else
       return null;
   }


   late LoginApi loginApi;
   login(String email,password) async {
     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
     Map data = {
       'userEmail': email,
       'userPassword': password,
     };

     var response = await http.post(Uri.parse("http://ec2-15-206-186-11.ap-south-1.compute.amazonaws.com/api/v1/user/userlogin"), body: data);
     loginApi = new LoginApi.fromJsonMap(json.decode(response.body.toString()));


     if(response.statusCode == 200) {
       // print("hello");
       // print(response.body);
       // print(loginApi.data);
        if(loginApi.status) {

         setState(() {
           _isLoading = false;
         });
         sharedPreferences.setString("Token",loginApi.data);
         sharedPreferences.setBool("isLoggedIn", true);

         // sharedPreferences.setString("NAME",loginApi.user.name);
         // sharedPreferences.setString("EMAIL",loginApi.user.email);
         // sharedPreferences.setString("PHONE",loginApi.user.phone);
         // sharedPreferences.setString("ADDRESS",loginApi.user.address);
         // Fluttertoast.showToast(
         //     msg:loginApi.message,
         //     toastLength: Toast.LENGTH_LONG,
         //     gravity: ToastGravity.BOTTOM,
         //     timeInSecForIosWeb: 2
         // );
         Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(
             builder: (BuildContext context) => HomePage()),
                 (Route<dynamic> route) => false);
       }
       // else{
       //   setState(() {
       //     _isLoading = true;
       //   });
       //   // Fluttertoast.showToast(
       //   //     msg: loginApi.message,
       //   //     toastLength: Toast.LENGTH_LONG,
       //   //     gravity: ToastGravity.BOTTOM,
       //   //     timeInSecForIosWeb: 2
       //   // print(response.body);
       // }
     }
     else {
       setState(() {
         _isLoading = false;
       });

     }
   }
   @override
   Widget build(BuildContext context) {
     return Scaffold(
       body:_isLoading ? Container(
           color: accentColor.withOpacity(0.4),
           child: Center(
               child: CircularProgressIndicator(
                 color: primaryColor,)))
           :Form(key: formKey,
           autovalidateMode: AutovalidateMode.always,
           child: SingleChildScrollView(
           child: Column(
             children: [
               SizedBox(height: 200,),
               Center(
                 child: (
                 Text(
                   "welcome",
                   style: TextStyle(
                     fontSize: 30,
                     fontWeight: FontWeight.bold
                   ),
                 )
                 ),
               ),
               Center(
                 child: (
                 Text(
                   "log in to continue",
                   style: TextStyle(
                     fontSize:30,
                     fontWeight: FontWeight.normal
                   ),
                 )
                 ),
               ),
               Container(
                 padding: EdgeInsets.only(left: 10, right: 10,top: 20, bottom: 20),
                     child: TextFormField(
                       controller: emailController,
                       keyboardType: TextInputType.emailAddress,
                           decoration: InputDecoration(
                             border: OutlineInputBorder(
                               borderRadius: BorderRadius.circular(10)
                             ),
                             fillColor: primaryColor.withOpacity(0.2),
                             filled: true,
                             prefixIcon:  Icon(Icons.email,size: 24,color: Color(0xFFF93822),),
                             enabledBorder: OutlineInputBorder(
                               borderSide: BorderSide(color:primaryColor),
                             ),
                             focusedBorder: OutlineInputBorder(
                               borderSide: BorderSide(color: Color(0xFFF93822)),
                             ),
                             errorBorder: OutlineInputBorder(
                               borderSide: BorderSide(color: Colors.redAccent),
                             ),
                             focusedErrorBorder: OutlineInputBorder(
                               borderSide: BorderSide(color:Colors.black),
                             ),
                             disabledBorder: OutlineInputBorder(
                               borderSide: BorderSide(color: Colors.white),
                             ),
                             labelText: 'Email',
                             labelStyle: TextStyle(color:Colors.grey ),
                             counter: Offstage(),
                           ),
                         validator: MultiValidator([
                           RequiredValidator(errorText: "* Required"),
                           EmailValidator(errorText: "Enter valid email id"),
                         ])
                     ),
               ),
               Container(
                 padding: EdgeInsets.only(left: 10, right: 10,top: 20, bottom: 20),
                 child: TextFormField(
                   controller: passwordController,
                   obscureText: _obscureTextNewPassword,
                   keyboardType: TextInputType.visiblePassword,
                   maxLength: 20,
                     decoration: InputDecoration(
                       prefixIcon:  Icon(Icons.email,size: 24,color: Color(0xFFF93822),),
                       border: OutlineInputBorder(
                         borderRadius: BorderRadius.all(Radius.circular(4.0)),
                         borderSide: BorderSide(width: 1.0),
                       ),
                       enabledBorder: OutlineInputBorder(
                         borderSide: BorderSide(color: Colors.grey),
                       ),
                       focusedBorder: OutlineInputBorder(
                         borderSide: BorderSide(color: Color(0xFFF93822)),
                       ),
                       errorBorder: OutlineInputBorder(
                         borderSide: BorderSide(color: Colors.redAccent),
                       ),
                       focusedErrorBorder: OutlineInputBorder(
                         borderSide: BorderSide(color:Color(0xFFF93822)),
                       ),
                       disabledBorder: OutlineInputBorder(
                         borderSide: BorderSide(color: Colors.white),
                       ),
                       labelText: 'Password',
                       labelStyle: TextStyle(color:Colors.grey ),
                       counter: Offstage(),
                       suffixIcon: new GestureDetector(
                         onTap: () {
                           setState(() {
                             _obscureTextNewPassword = !_obscureTextNewPassword;
                           });
                         },
                         child:
                         new Icon(_obscureTextNewPassword ? Icons.visibility : Icons.visibility_off ,
                             color: accentColor,
                             size: 24
                         ),
                       ),
                   ),
                     validator: MultiValidator([
                       RequiredValidator(errorText: "* Required"),
                       MinLengthValidator(6,
                           errorText: "Password should be atleast 6 characters"),
                       MaxLengthValidator(15,
                           errorText:
                           "Password should not be greater than 15 characters")
                     ])
                 ),

               ),
               Padding(padding: EdgeInsets.only(right: 15,left: 15,top: 50,bottom: 15),
                 child: MaterialButton(
                   color: accentColor,
                   height: 40,
                   minWidth: 200,
                   padding: EdgeInsets.only(right: 16,left: 16),
                   onPressed: ()  {
                     final form = formKey.currentState;
                     if (form!.validate()) {
                       setState(() {
                         _isLoading = true;
                       });
                       login(emailController.text, passwordController.text);
                     }

                   },
                   child: Text("login".toUpperCase(),
                   style: TextStyle(
                     fontWeight: FontWeight.bold
                   ),),

                   ),
                 ),
             ],

           ),
         ),
       ),

     );
   }
 }



